﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using SnakesAndLaddersKata.DiceClasses;
using SnakesAndLaddersKata.TokenClasses;

namespace SnakesAndLaddersKata.PlayerClasses
{
    public class Player:AbstractPlayer
    {
        private readonly IDice _dice;
        private readonly IToken _token;

        public Player(IDice dice, IToken token)
        {
            _dice = dice;
            _token = token;
        }
        public override async Task<string> Roll()
        {
            int diceResult = await _dice.RollADice();
            Console.WriteLine($"Current Dice:{diceResult}");
            int currentSquare = GetProgress();
            Console.WriteLine($"Current Square:{currentSquare}");
            if (currentSquare == 100)
            {
                Console.WriteLine("");
                Console.WriteLine("");
                Console.WriteLine("Player has Won");
                return "Won";
            }

                if (currentSquare + diceResult <= 100)
                {
                    int square = await _token.MoveToken(currentSquare, diceResult);

                    Console.WriteLine($"New Square:{square}");
                    SetProgress(square);

                    

                    if (square==100)
                    {
                        Console.WriteLine("");
                        Console.WriteLine("");
                        Console.WriteLine("Player has Won");
                        return "Won";
                    }
                }
                else
                {
                    Console.WriteLine("");
                    Console.WriteLine("Not Won");
                }   

            

            
            return "Not won";
        }
    }
}
