﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using SnakesAndLaddersKata.DiceClasses;
using SnakesAndLaddersKata.TokenClasses;

namespace SnakesAndLaddersKata.PlayerClasses
{
    public class PlayerOne:IPlayer
    {
        private readonly IDice _dice;
        private readonly IToken _token;

        public PlayerOne(IDice dice, IToken token)
        {
            _dice = dice;
            _token = token;
        }

        public Task Roll()
        {
            throw new NotImplementedException();
        }
    }
}
