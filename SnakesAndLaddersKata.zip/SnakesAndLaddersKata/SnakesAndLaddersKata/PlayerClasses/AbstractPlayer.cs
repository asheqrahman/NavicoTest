﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace SnakesAndLaddersKata.PlayerClasses
{
    public abstract class AbstractPlayer
    {
        private static int currentSquare;

        public abstract Task<string> Roll();

        public  int GetProgress()
        {
            return  currentSquare;
        }

        public void SetProgress(int square)
        {
            currentSquare =  square;
        }

    }
}
