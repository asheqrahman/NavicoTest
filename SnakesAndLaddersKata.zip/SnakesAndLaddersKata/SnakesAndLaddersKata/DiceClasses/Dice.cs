﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using SnakesAndLaddersKata.TokenClasses;

namespace SnakesAndLaddersKata.DiceClasses
{
    public class Dice:IDice
    {

        public async Task<int> RollADice()
        {
            Random _rand = new Random();

            return _rand.Next(1, 6);
        }
    }
}
