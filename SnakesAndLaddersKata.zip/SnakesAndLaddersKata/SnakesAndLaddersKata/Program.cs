﻿using System;
using System.Threading;
using Microsoft.Extensions.DependencyInjection;
using SnakesAndLaddersKata.DiceClasses;
using SnakesAndLaddersKata.PlayerClasses;
using SnakesAndLaddersKata.TokenClasses;

namespace SnakesAndLaddersKata
{
    class Program
    {
        static void Main(string[] args)
        {

            var services = new ServiceCollection();

            services.AddSingleton<IDice, Dice>();
            services.AddSingleton<IToken, Token>();


            var provider = services.BuildServiceProvider();

            var diceService = provider.GetRequiredService<IDice>();

            var tokenService = provider.GetRequiredService<IToken>();


            Player firstPlayer = new Player(dice: diceService, token: tokenService);

            Player secondPlayer = new Player(dice: diceService, token: tokenService);

            new Thread(() =>
            {
                while (!firstPlayer.Roll().Result.Equals("Won"))
                {
                    Console.WriteLine("");
                    Console.WriteLine("");
                    Console.WriteLine("First Player still Playing");


                }
            }).Start();


            new Thread(() =>
            {
                while (!secondPlayer.Roll().Result.Equals("Won"))
                {
                    Console.WriteLine("");
                    Console.WriteLine("");
                    Console.WriteLine("Second Player still Playing");


                }
            }).Start();

            
            Console.ReadLine();
        }
    }
}
