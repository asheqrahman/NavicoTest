﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace SnakesAndLaddersKata.TokenClasses
{
    public interface IToken
    {
        Task<int> MoveToken(int currentSquare,int nextSquare); // return (currentSquare + nextSquare)  This is how Player will move to next the square 


    }
}
