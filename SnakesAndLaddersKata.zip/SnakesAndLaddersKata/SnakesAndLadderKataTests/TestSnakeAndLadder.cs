using System;
using System.Threading.Tasks;
using Moq;
using SnakesAndLaddersKata.DiceClasses;
using SnakesAndLaddersKata.PlayerClasses;
using SnakesAndLaddersKata.TokenClasses;
using Xunit;

namespace SnakesAndLadderKataTests
{
    public class TestSnakeAndLadder
    {
        [Fact]
        public void Given_the_token_is_on_square_1_When_the_token_is_moved_3_spaces_Then_the_token_is_on_square_4()
        {
            int currentSquare = 1;
            int expectedDiceResult = 3;
            int expectedSquare = 4;

            var diceResult = new Mock<IDice>();

            diceResult.Setup(x => x.RollADice()).Returns(Task<int>.FromResult(expectedDiceResult));

            var moveToken = new Mock<IToken>();

            moveToken.Setup(t => t.MoveToken(It.IsAny<int>(), It.IsAny<int>())).Returns(Task<int>.FromResult(expectedSquare));

            Player player = new Player(diceResult.Object, moveToken.Object);
            var roll = player.Roll();
            Assert.Equal(expectedSquare, player.GetProgress());
        }


        [Fact]
        public void Given_the_token_is_on_square_1_When_the_token_is_moved_3_spaces_And_then_it_is_moved_4_spaces_Then_the_token_is_on_square_8()
        {
            int FirstcurrentSquare = 1;
            int SecondcurrentSquare = 4;

            int FirstexpectedDiceResult = 3;
            int SecondexpectedDiceResult = 4;

            int FirstexpectedSquare = 4;
            int SecondexpectedSquare = 8;

            var diceResult = new Mock<IDice>();
            var moveToken = new Mock<IToken>();

            //--------------First Roll
            diceResult.Setup(x => x.RollADice()).Returns(Task<int>.FromResult(FirstexpectedDiceResult));
            
            moveToken.Setup(t => t.MoveToken(It.IsAny<int>(), It.IsAny<int>())).Returns(Task<int>.FromResult(FirstexpectedSquare));

            Player player = new Player(diceResult.Object, moveToken.Object);
            var roll1 = player.Roll();
            Assert.Equal(FirstexpectedSquare, player.GetProgress());


            //--------------Second Roll
            diceResult.Setup(x => x.RollADice()).Returns(Task<int>.FromResult(SecondexpectedDiceResult));

            moveToken.Setup(t => t.MoveToken(It.IsAny<int>(), It.IsAny<int>())).Returns(Task<int>.FromResult(SecondexpectedSquare));

            var roll2 = player.Roll();
            

            Assert.Equal(SecondexpectedSquare, player.GetProgress());
        }

        [Fact]
        public async Task Given_the_game_is_started_When_the_player_rolls_a_die_Then_the_result_should_be_between_1_And_6_inclusive()
        {
            
            int minimumDiceResult = 1;
            int maximumDiceResult = 6;
            int expectedDiceResult ;

            var dice=new Dice();
            expectedDiceResult = await dice.RollADice();
            Assert.InRange(expectedDiceResult,minimumDiceResult,maximumDiceResult);
        }

        [Fact]
        public void Given_the_player_rolls_a_4_When_they_move_their_token_Then_the_token_should_move_4_spaces()
        {
            int currentSquare = 1;
            int expectedDiceResult = 4;
            int expectedSquare = 5;

            var diceResult = new Mock<IDice>();

            diceResult.Setup(x => x.RollADice()).Returns(Task<int>.FromResult(expectedDiceResult));

            var moveToken = new Mock<IToken>();

            moveToken.Setup(t => t.MoveToken(It.IsAny<int>(), It.IsAny<int>())).Returns(Task<int>.FromResult(expectedSquare));

            Player player = new Player(diceResult.Object, moveToken.Object);
            var roll = player.Roll();
            Assert.Equal(expectedSquare, player.GetProgress());
        }

        [Fact]
        public void Given_the_token_is_on_square_97_When_the_token_is_moved_3_spaces_Then_the_token_is_on_square_100_And_the_player_has_won_the_game()
        {
            int currentSquare = 97;
            int expectedDiceResult = 3;
            int expectedSquare = 100;
            string expectedResult = "Won";

            var diceResult = new Mock<IDice>();

            diceResult.Setup(x => x.RollADice()).Returns(Task<int>.FromResult(expectedDiceResult));

            var moveToken = new Mock<IToken>();

            moveToken.Setup(t => t.MoveToken(It.IsAny<int>(), It.IsAny<int>())).Returns(Task<int>.FromResult(expectedSquare));

            Player player = new Player(diceResult.Object, moveToken.Object);
            var roll = player.Roll();
            //Assert.Equal(expectedSquare, player.GetProgress());
            Assert.Equal(expectedResult, roll.Result);

        }

        [Fact]
        public void Given_the_token_is_on_square_97_When_the_token_is_moved_4_spaces_Then_the_token_is_on_square_97_And_the_player_has_not_won_the_game()
        {
            int currentSquare = 97;
            int expectedDiceResult = 4;
            int expectedSquare = 97;
            string expectedResult = "Not won";

            var diceResult = new Mock<IDice>();

            diceResult.Setup(x => x.RollADice()).Returns(Task<int>.FromResult(expectedDiceResult));

            var moveToken = new Mock<IToken>();

            moveToken.Setup(t => t.MoveToken(It.IsAny<int>(), It.IsAny<int>())).Returns(Task<int>.FromResult(expectedSquare));

            Player player = new Player(diceResult.Object, moveToken.Object);
            var roll = player.Roll();
            //Assert.Equal(expectedSquare, player.GetProgress());
            Assert.Equal(expectedResult, roll.Result);
        }


        [Fact]
        public void Player_Will_Move_One_Square_If_Dice_Result_Is_One()
        {
            int currentSquare = 1;
            int expectedDiceResult = 1;
            int expectedSquare = 2;

            var diceResult = new Mock<IDice>();

            diceResult.Setup(x => x.RollADice()).Returns(Task<int>.FromResult(expectedDiceResult));

            var moveToken = new Mock<IToken>();

            moveToken.Setup(t => t.MoveToken(It.IsAny<int>(), It.IsAny<int>())).Returns(Task<int>.FromResult(expectedSquare));

            Player player = new Player(diceResult.Object, moveToken.Object);
            var roll = player.Roll();
            Assert.Equal(expectedSquare, player.GetProgress());

        }

        [Fact]
        public void Player_Will_Move_Six_Square_If_Dice_Result_Is_Six()
        {
            int currentSquare = 1;
            int expectedDiceResult = 6;
            int expectedSquare = 6;

            var diceResult = new Mock<IDice>();

            diceResult.Setup(x => x.RollADice()).Returns(Task<int>.FromResult(expectedDiceResult));

            var moveToken = new Mock<IToken>();

            moveToken.Setup(t => t.MoveToken(It.IsAny<int>(), It.IsAny<int>())).Returns(Task<int>.FromResult(expectedSquare));

            Player player = new Player(diceResult.Object, moveToken.Object);
            var roll = player.Roll();
            Assert.Equal(expectedSquare, player.GetProgress());

        }
    }
}
